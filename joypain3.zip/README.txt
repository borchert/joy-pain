The contents of this archive were generated using the ArcGIS API for JavaScript
Web Optimizer.

To host this build of the ArcGIS API for JavaScript on your server, first extract
the contents of this archive into a directory on your server.  Then, in any
Web pages intending to use this build, add (or update) a script tag to reference
the dojo/dojo.js file extracted from this archive:

<script src="path/to/dojo/dojo.js" data-dojo-config="async: true"></script>

At minimum, you will generally want to set the async config option to true as
indicated above, in order for the Dojo loader to operate in asynchronous mode.

If you previously used the packages or paths configuration settings in
development, they should not be necessary with this built release, as all
packages have been arranged as siblings of the dojo package.

If your Web page or application referenced CSS resources within Dojo's, Esri's,
or your own custom packages, you will also want to reference the respective
flattened CSS resources in this built release instead.

If you have any questions or comments, please submit them through the Esri
Support Center at <http://support.esri.com/>.