This folder contains images used by all themes when in "high-contrast" mode.

If you think you need to put something here, please talk to Becky or Bill first.